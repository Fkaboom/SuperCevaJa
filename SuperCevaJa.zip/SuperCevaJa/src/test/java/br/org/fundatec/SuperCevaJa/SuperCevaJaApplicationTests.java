package br.org.fundatec.SuperCevaJa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperCevaJaApplicationTests {

	@Test
	void contextLoads() {
	}

}
